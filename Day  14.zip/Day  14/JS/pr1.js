$(document).ready(function(){
    $("#maintabdiv").tabs();
});
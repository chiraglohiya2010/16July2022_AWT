$(document).ready(function(){
$("#Agerangeslider").slider({
    min: 18,
    max: 100,
    value: 18,
    slide: function(event, ui){
        $("#Agevalue").val(ui.value);
    }
});
$("#Agevalue").val($("#AgerangeSlider").slider("value"));
$("#Pricevalue").slider({
    min: 1,
    max: 500,
    range:true,
    values:[1,50],
    start: function(event, ui){
        $("#Startvalue")
        .val("$"+ ui.values[0]);
    },
    stop: function (event, ui){
        $("#Endvalue")
        .val("$"+ ui.values[1]);
    },
    change: function (event, ui){
        $("#Changevalue")
        .val("$"+ ui.values[0] + "-$" + ui.values[1]);
    },
    slide: function (event, ui){
        $("#Slidevalue")
        .val("$"+ ui.values[0] + "-$" + ui.values[1]);
    },
    
});
});
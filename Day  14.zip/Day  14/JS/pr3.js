$(document).ready(function(){
    $(".Maindiv").draggable();

    $(".containment span").draggable({
        containmnet: ".containment"
    });

    $(".AxisX span").draggable({
        axis: "x"
    });

    $(".AxisY span").draggable({
        axis: "y"
    });

    $(".Delay span").draggable({
        delay: 3000
    });

    $(".Distance span").draggable({
        Distance: 200
    });
})